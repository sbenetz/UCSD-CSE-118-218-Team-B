#!/bin/bash
# -- Kills any process running on the given port --

# Check if a port number is provided as an argument
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <port_number>"
    exit 1
fi

# Assign the provided port number to a variable
PORT_NUMBER="$1"

CURR_PROC_PID=$(lsof -i :${PORT_NUMBER} | awk 'NR==2 {print $2}')
if [ -n "${CURR_PROC_PID}" ]; then
  echo "Port ${PORT_NUMBER} in use. Killing process ${CURR_PROC_PID}"
  kill ${CURR_PROC_PID}
fi